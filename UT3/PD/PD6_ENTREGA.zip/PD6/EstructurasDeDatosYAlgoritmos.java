package org.example.UT3.PD6;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.LinkedList;

public class EstructurasDeDatosYAlgoritmos {
    public class EstructurasYAlgoritmos {
        String nombre;
        Lista<String> sucursales = new Lista<>();

        public EstructurasYAlgoritmos() {
            this.nombre = nombre;
        }

        public String getNombre() {
            return nombre;
        }

        public void agregarSucursal(String nombre) {
            if (sucursales.buscar(nombre) == null) {
                sucursales.insertar(nombre);
            }

        }

        public void quitarSucursal(String nombre) {
            if (sucursales.buscar(nombre) != null) {
                sucursales.eliminar(nombre);
            }

        }

        public void listarSucursales() {
            sucursales.imprimir();
        }

        public void cantidadDeSucursales() {
            System.out.println("La cantidad de sucursales son: " + sucursales.cantElementos());
        }

        public void isEmpty() {
            if (sucursales.esVacia()) {
                System.out.println("La cantidad de sucursales es vacia");
            } else {
                System.out.println("La cantidad de sucursales no es vacia");
            }
        }
        public void ciudadSiguiente(String nombre) {
            Nodo<String> sucursal = sucursales.buscar(nombre);
            String siguiente = sucursal.getSiguiente().getDato();

            System.out.println(siguiente);
        }
        public void imprimirLista() {
            sucursales.imprimir(";_");
        }

        public void cargarArchivo(String archivo) {
            try
                    (BufferedReader br = new BufferedReader(new FileReader(archivo))){
                String linea;
                while ((linea = br.readLine()) != null) {
                    agregarSucursal(linea.trim());
                }
                imprimirLista();

            }
            catch (Exception e) {
                throw new RuntimeException(e);
            }

        }
    }
}
