package org.example.UT3.PD6;

public class Lista<T> implements ILista<T> {

    private Nodo<T> primero;
    private Nodo<T> ultimo;
    private int cantidad;

    public Lista() {
        primero = null;
        ultimo = null;
    }

    @Override
    public Nodo<T> getPrimero() {
        return primero;
    }

    @Override
    public Nodo<T> getUltimo() {
        return ultimo;
    }

    @Override
    public void insertar(T dato) {
        Nodo<T> nuevo = new Nodo<T>(dato);
        if (primero == null){
            primero = nuevo;
            ultimo = nuevo;
            cantidad++;
            return;
        }
        ultimo.setSiguiente(nuevo);
        ultimo = ultimo.getSiguiente();
        cantidad++;
    }

    @Override
    public Nodo<T> buscar(T dato) {
        Nodo<T> actual = primero;
        while (actual != null) {
            if (actual.getDato().equals(dato)) {
                return actual;
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    @Override
    public boolean eliminar(T dato) {
        if (this.primero == null) {
            return false;
        }
        if (this.primero.getDato().equals(dato)) {
            this.primero = primero.getSiguiente();
            cantidad--;
            return true;
        }

        Nodo<T> anterior = this.primero;
        Nodo<T> actual = this.primero;

        while (actual != null) {
            if (actual.getDato().equals(dato)) {
                anterior.setSiguiente(actual.getSiguiente());
                cantidad--;
                return true;
            }
            anterior = actual;
            actual = actual.getSiguiente();
        }

        return false;
    }

    @Override
    public String imprimir() {
        if (this.primero == null) {
            return "Lista vacia";
        }
        StringBuilder sb = new StringBuilder();
        Nodo<T> nodo = primero;
        while (nodo != null) {
            sb.append(nodo.getDato()).append("\n");  // Acumula todos los productos
            nodo = nodo.getSiguiente();
        }
        return sb.toString();
    }

    @Override
    public String imprimir(String separador) {
        StringBuilder claves = new StringBuilder();
        Nodo<T> nodo = primero;
        while (nodo != null) {
            claves.append(separador);
            claves.append(nodo.getDato());
            nodo = nodo.getSiguiente();
        } return (claves.toString());
    }

    @Override
    public int cantElementos() {
        return cantidad;
    }

    @Override
    public boolean esVacia() {
        return primero == null;
    }

}
